<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="sk">
<dependencies>
<dependency catalog="qtbase_sk"/>
<dependency catalog="qtscript_sk"/>
<dependency catalog="qtmultimedia_sk"/>
<dependency catalog="qtxmlpatterns_sk"/>
</dependencies>
</TS>
